import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'dart:convert';

void main() {
  runApp(MaterialApp(home: ZakazkyApp()));
}

class ZakazkyApp extends StatefulWidget {
  @override
  _ZakazkyAppState createState() => _ZakazkyAppState();
}

class _ZakazkyAppState extends State<ZakazkyApp> {
  List<Map<String, String>> zakazky = [];
  final TextEditingController controller = TextEditingController();
  String vybranyStav = 'Čaká';
  String aktivnyFilter = 'Všetky';
  String vyhladavanieText = '';
  String poradie = 'žiadne';

  @override
  void initState() {
    super.initState();
    nacitajZakazky();
  }
  void pridajZakazku() {
    final text = controller.text.trim();
    if (text.isNotEmpty) {
      final teraz = DateTime.now();
      final formatovany = DateFormat('d.M.yyyy HH:mm').format(teraz);
      final termin = teraz.add(Duration(days: 3));
      setState(() {
        zakazky.add({
          'nazov': text,
          'stav': vybranyStav,
          'datum': formatovany,
          'termin': termin.toIso8601String(),
        });
      });
      ulozZakazky();
      controller.clear();
      vybranyStav = 'Čaká';
    }
  }

  Future<void> ulozZakazky() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = jsonEncode(zakazky);
    await prefs.setString('zakazky', jsonString);
  }

  Future<void> nacitajZakazky() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString('zakazky');
    if (jsonString != null) {
      final decoded = jsonDecode(jsonString) as List;
      setState(() {
        zakazky = decoded.map((e) => Map<String, String>.from(e)).toList();
      });
    }
  }

  List<Map<String, String>> get zakazkyFiltrovanie {
    var filtro = zakazky.where((z) {
      final nazov = z['nazov']?.toLowerCase() ?? '';
      final vyhl = vyhladavanieText.toLowerCase();
      return (aktivnyFilter == 'Všetky' || z['stav'] == aktivnyFilter) &&
             nazov.contains(vyhl);
    }).toList();

    if (poradie != 'žiadne') {
      filtro.sort((a, b) {
        final t1 = DateTime.tryParse(a['termin'] ?? '');
        final t2 = DateTime.tryParse(b['termin'] ?? '');
        if (t1 == null && t2 == null) return 0;
        if (t1 == null) return 1;
        if (t2 == null) return -1;
        return poradie == 'vzostupne'
            ? t1.compareTo(t2)
            : t2.compareTo(t1);
      });
    }

    return filtro;
  }

  String getOdpocetText(String? iso) {
    if (iso == null) return '';
    final termin = DateTime.tryParse(iso);
    if (termin == null) return '';
    final dnes = DateTime.now();
    final rozdiel = termin.difference(dnes).inDays;
    if (rozdiel < 0) return '⚠️ Po termíne!';
    if (rozdiel == 0) return '📍 Dnes!';
    if (rozdiel == 1) return '1 deň zostáva';
    return '$rozdiel dní zostáva';
  }

  Color getFarbaOdpocet(String? iso) {
    if (iso == null) return Colors.grey;
    final termin = DateTime.tryParse(iso);
    if (termin == null) return Colors.grey;
    final rozdiel = termin.difference(DateTime.now()).inDays;
    if (rozdiel < 0) return Colors.red;
    if (rozdiel <= 1) return Colors.orange;
    return Colors.green;
  }

  Color getFarbaPodlaStavu(String? stav) {
    switch (stav) {
      case 'Hotovo':
        return Colors.green;
      case 'Čaká':
        return Colors.orange;
      case 'V riešení':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Zákazky'),
        actions: [
          IconButton(
            onPressed: exportujZakazky,
            icon: Icon(Icons.cloud_upload),
            tooltip: 'Exportovať JSON',
          ),
          IconButton(
            onPressed: importujZakazky,
            icon: Icon(Icons.cloud_download),
            tooltip: 'Importovať JSON',
          ),
          IconButton(
            onPressed: exportujCSV,
            icon: Icon(Icons.table_chart),
            tooltip: 'Exportovať CSV',
          ),
IconButton(
  onPressed: () {
    setState(() => poradie = 'vzostupne');
  },
  icon: Icon(
    Icons.arrow_upward,
    color: poradie == 'vzostupne' ? Colors.orange : Colors.grey,
  ),
  tooltip: 'Zoradiť vzostupne',
),
IconButton(
  onPressed: () {
    setState(() => poradie = 'klesajúco');
  },
  icon: Icon(
    Icons.arrow_downward,
    color: poradie == 'klesajúco' ? Colors.orange : Colors.grey,
  ),
  tooltip: 'Zoradiť zostupne',
),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      decoration: InputDecoration(
                        labelText: 'Zadaj názov zákazky',
                        suffixIcon: DropdownButton<String>(
                          value: vybranyStav,
                          onChanged: (val) =>
                              setState(() => vybranyStav = val ?? 'Čaká'),
                          items: ['V riešení', 'Čaká', 'Hotovo']
                              .map((stav) => DropdownMenuItem(
                                  value: stav, child: Text(stav)))
                              .toList(),
                        ),
                      ),
                      onSubmitted: (_) => pridajZakazku(),
                    ),
                  ),
                  SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: pridajZakazku,
                    child: Text('Pridať'),
                  ),
                ],
              ),
            ),
            Wrap(
              spacing: 8,
              children: ['Všetky', 'V riešení', 'Čaká', 'Hotovo']
                  .map((stav) => ChoiceChip(
                        label: Text(stav),
                        selected: aktivnyFilter == stav,
                        onSelected: (_) =>
                            setState(() => aktivnyFilter = stav),
                      ))
                  .toList(),
            ),
            Padding(
              padding: EdgeInsets.only(top: 12),
              child: TextField(
                decoration: InputDecoration(labelText: 'Vyhľadávanie'),
                onChanged: (val) =>
                    setState(() => vyhladavanieText = val.trim()),
              ),
            ),
            SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: zakazkyFiltrovanie.length,
                itemBuilder: (_, index) {
                  final z = zakazkyFiltrovanie[index];
                  return ListTile(
                    title: Text(z['nazov'] ?? ''),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if ((z['poznamka'] ?? '').isNotEmpty)
                          Text(
                            z['poznamka']!,
                            style: TextStyle(color: Colors.grey[700]),
                          ),
                        Text(
                          z['datum'] ?? '',
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                        if (z['termin'] != null)
                          Text(
                            getOdpocetText(z['termin']),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: getFarbaOdpocet(z['termin']),
                            ),
                          ),
                      ],
                    ),
                    leading: CircleAvatar(
                      backgroundColor: getFarbaPodlaStavu(z['stav']),
                    ),
                    trailing: Text(z['stav'] ?? ''),
                    onTap: () => upravitZakazku(zakazky.indexOf(z)),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
  void exportujZakazky() {
    final json = JsonEncoder.withIndent('  ').convert(zakazky);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Export zákaziek'),
        content: SingleChildScrollView(child: SelectableText(json)),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: json));
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Skopírované do schránky')),
              );
            },
            child: Text('Kopírovať'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Zatvoriť'),
          ),
        ],
      ),
    );
  }

  void importujZakazky() {
    final textController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Import zákaziek'),
        content: TextField(
          controller: textController,
          maxLines: 10,
          decoration: InputDecoration(hintText: 'Vlož JSON sem'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              try {
                final parsed = jsonDecode(textController.text);
                if (parsed is List) {
                  final loaded = parsed.map((e) {
                    final map = Map<String, dynamic>.from(e);
                    return {
                      'nazov': map['nazov'] ?? '',
                      'stav': map['stav'] ?? 'Čaká',
                      'datum': map['datum'] ?? '',
                      'poznamka': map['poznamka'] ?? '',
                      'termin': map['termin'] ?? '',
                    };
                  }).toList();
                  setState(() => zakazky = List<Map<String, String>>.from(loaded));
                  ulozZakazky();
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Import úspešný')),
                  );
                } else {
                  throw Exception();
                }
              } catch (_) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Neplatný JSON')),
                );
              }
            },
            child: Text('Načítať'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Zrušiť'),
          ),
        ],
      ),
    );
  }

  void exportujCSV() {
    final buffer = StringBuffer();
    buffer.writeln('Názov,Stav,Dátum');
    for (var z in zakazky) {
      final nazov = z['nazov']?.replaceAll(',', ' ') ?? '';
      final stav = z['stav'] ?? '';
      final datum = z['datum'] ?? '';
      buffer.writeln('$nazov,$stav,$datum');
    }
    final csv = buffer.toString();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Export CSV'),
        content: SingleChildScrollView(child: SelectableText(csv)),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: csv));
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('CSV skopírovaný do schránky')),
              );
            },
            child: Text('Kopírovať'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Zatvoriť'),
          ),
        ],
      ),
    );
  }

  void upravitZakazku(int index) {
    final zakazka = zakazky[index];
    final controllerEdit = TextEditingController(text: zakazka['nazov']);
    final controllerPoznamka = TextEditingController(text: zakazka['poznamka'] ?? '');
    String novyStav = zakazka['stav'] ?? 'Čaká';
    DateTime? zvolenyTermin = zakazka['termin'] != null
        ? DateTime.tryParse(zakazka['termin']!)
        : null;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateDialog) {
          return AlertDialog(
            title: Text('Upraviť zákazku'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: controllerEdit,
                  decoration: InputDecoration(labelText: 'Nový názov'),
                ),
                DropdownButtonFormField<String>(
                  value: novyStav,
                  decoration: InputDecoration(labelText: 'Zmeniť stav'),
                  onChanged: (val) =>
                      setStateDialog(() => novyStav = val ?? 'Čaká'),
                  items: ['V riešení', 'Čaká', 'Hotovo']
                      .map((stav) =>
                          DropdownMenuItem(value: stav, child: Text(stav)))
                      .toList(),
                ),
                TextField(
                  controller: controllerPoznamka,
                  decoration: InputDecoration(labelText: 'Poznámka'),
                  maxLines: 3,
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        zvolenyTermin != null
                            ? 'Termín: ${DateFormat('d.M.yyyy').format(zvolenyTermin!)}'
                            : 'Bez termínu',
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                    TextButton(
                      onPressed: () async {
                        final vybrany = await showDatePicker(
                          context: context,
                          initialDate: zvolenyTermin ?? DateTime.now(),
                          firstDate: DateTime(2023),
                          lastDate: DateTime(2100),
                        );
                        if (vybrany != null) {
                          setStateDialog(() => zvolenyTermin = vybrany);
                        }
                      },
                      child: Text('Vybrať termín'),
                    ),
                    if (zvolenyTermin != null)
                      TextButton(
                        onPressed: () =>
                            setStateDialog(() => zvolenyTermin = null),
                        child: Text('Zmazať'),
                      ),
                  ],
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  final upraveny = controllerEdit.text.trim();
                  if (upraveny.isNotEmpty) {
                    setState(() {
                      zakazky[index]['nazov'] = upraveny;
                      zakazky[index]['stav'] = novyStav;
                      zakazky[index]['poznamka'] = controllerPoznamka.text.trim();
                      zakazky[index]['termin'] =
                          zvolenyTermin?.toIso8601String() ?? '';
                    });
                    ulozZakazky();
                  }
                  Navigator.pop(context);
                },
                child: Text('Uložiť'),
              ),
              TextButton(
                onPressed: () {
                  setState(() => zakazky.removeAt(index));
                  ulozZakazky();
                  Navigator.pop(context);
                },
                child: Text('Zmazať'),
              ),
            ],
          );
        },
      ),
    );
  }

}
