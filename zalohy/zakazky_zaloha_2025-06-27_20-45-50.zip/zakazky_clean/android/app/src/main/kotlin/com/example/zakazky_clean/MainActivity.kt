package com.example.zakazky_clean

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
